# GRAND-CHUKUCHUKU
## Character Bible v2 — Fiango and the wider story

**Purpose:** A visual and performance guide for every character presently identified from Zino's account.  
**Visual scope:** The four illustrated sheets lock only the proposed animation language. They do not claim to reproduce a real person’s likeness.  
**Source rule:** `C` means confirmed by Zino; `FT` means family testimony; `P` means a proposed storytelling or visual choice.

## Cast at a glance

| Character | Story role | Current design status |
| --- | --- | --- |
| **Nkeh “Zino” Nkengzincho** | The boy at the centre of the story | Illustrated design proposal for Chapter One age 10; turnarounds and later-life variants remain open. |
| **Grand-Chukuchuku** | Zino’s invented adult ideal | Illustrated and locked to the author-supplied adult model sheet. |
| **Gideon** | Entrepreneurial best friend | Illustrated for a proposed later day-school look. |
| **Luc** | Faithful, candid best friend | Illustrated for a proposed later day-school look. |
| **Elianne** | Previously named first love; identity/place unresolved | Illustrated as a proposed school-era design; chronology is open. |
| **Zino’s Mother** | Single mother and primary-school teacher | Illustrated; name, exact age and wardrobe history remain open. |
| **Zino’s Paternal Uncle** | Occasional school-fee support and promise-maker | Lawyer-era suit illustrated; name and financial circumstances remain open. |
| **Zino’s Father** | Absent father; family-loss foundation | Shown only as a respectful nonliteral memory portrait. |
| **Miss Mukete** | Favourite chemistry teacher | Illustrated; name is supplied, but individual history and exact likeness remain open. |
| **The Landlord** | Compound money pressure | Illustrated as an unnamed composite. |

---

# 01 — Zino and Grand-Chukuchuku

**Visual sheet:** `images/01_Zino_and_Grand.png`

### NKEH “ZINO” NKENGZINCHO

**Story role:** The gifted boy who can turn defeat into a story, then must learn that wit cannot solve every material problem.

- **C — Foundation:** Born 1990; in Chapter One’s opening he is ten in Fiango, Kumba. He is intelligent, witty, kind and strongly drawn to justice. He speaks Pidgin with friends, English at home, and French and English at school. He wants to build his mother a house. His weaknesses include temper, people-pleasing and limited self-awareness.
- **P — Distinct visual code:** Slim, quick-footed silhouette; short tapered curls; bright, watchful eyes; expressive brow; faded white football vest, worn blue shorts and bare feet for street play. His face must carry the same brow, hairline and quick smile as Grand’s.
- **Performance:** Words arrive before caution. When Zino is frightened, reduce the speed of his speech rather than remove his humour. His anger is hot and immediate, but never his entire personality.
- **Props:** Scuffed ball, school bag, folded exercise-book page, small coins, well bucket.
- **C — Learning, music and faith:** Maths is his favourite, puzzle-like subject; he understands science readily. Singing precedes his own songwriting in Form Five; his first demo follows his return from boarding high school, and he writes later in America. Catholic; primary-school altar service stops for lack of time in secondary school, not a supplied loss of faith.
- **Do not do:** Do not turn cleverness into invulnerability, poverty into costume, or childhood into an adult body language.

### GRAND-CHUKUCHUKU

**Story role:** Zino’s fictional ideal man—the person in his impossible stories who can do what nobody else can.

- **C — Foundation:** Grand-Chukuchuku is Zino’s invented ideal person. He is not a literal future Zino, a ghost or a superhero. He appears when Zino actively makes a story border reality and fiction.
- **C — Locked baseline:** Short tapered curls, close beard, warm brown complexion, navy suit, open white shirt, brown shoes and a composed, expressive bearing come from the author-supplied model sheet.
- **P — Distinct visual code:** Navy, cream and precise gold reflections; stillness before action; controlled eye line; one hand in a pocket or relaxed at his side. His fantasy entrance alters light and motion, not physical reality.
- **Performance:** He does not chatter. He is confident because Zino needs him to be. As the story darkens, he appears less often and can fail to arrive.
- **Do not do:** No flying, capes, superpowers, combat poses or literal rescue of real-world consequences.

---

# 02 — Gideon, Luc and Elianne

**Visual sheet:** `images/02_Friends_and_Elianne.png`

### GIDEON

**Story role:** The business-minded friend who sees the price, the opportunity and the camera angle before others do.

- **C — Foundation:** Gideon is sharp, focused and always looking for ways to make money. He bought his first camera when he went to secondary school, booked birthday-party camera gigs, often paid for small outings with Zino, and liked Zino’s help approaching girls because Gideon was quiet and found it hard to keep a conversation going.
- **C / P — Revised visual code:** W-shaped hairline and fuller, almost-afro hair; camera and cross-body bag. School uniform is sky-blue short sleeves with dark-blue trousers. Casual wardrobe remains proposed and separate. His gaze should measure a room before he enters it.
- **C — Football correction:** He does not play; he sits watching and bantering, especially when Zino loses.
- **Performance:** His jokes land dry. He speaks only after he has calculated the situation. When he laughs freely, the audience should feel that trust has been earned.
- **C — Later detail:** Zino calls him Giddy. Constant trades and paid services; a market place selling bread by Form Five. He asks Zino to explain schoolwork. Market terms and prices remain open.
- **Do not do:** Do not make him a comic coward or a sidekick whose only purpose is to pay bills.

### LUC

**Story role:** The moral pressure inside the friendship group: faith, fairness and honesty without self-righteousness.

- **C — Foundation:** Luc is God-fearing, carries a small Bible, preaches to fellow students, and values Zino’s honesty, humour, help with mathematics and conversations about girls.
- **C / P — Revised visual code:** Muscular build from evening weights; high flat-top; small Bible. Mud-formed dumbbells and a sand-filled punching bag are confirmed training props. Light sky-blue short-sleeved shirt with dark-blue trousers. He does not play football. Training onset is open; do not give his age-ten version adult musculature. His stillness should contrast with Zino’s restless movement.
- **Performance:** Clear and direct. He has courage to speak in public even when nobody listens. His faith should guide action, not produce speeches in every scene.
- **C — Nickname:** Zino calls him Lucky Luc when meeting him alone; the date this begins is open.
- **Do not do:** Never reduce Luc to a punchline, a hypocrite or an automatic judge of his friends.

### ELIANNE

**Story role:** Zino’s first love and a person whose life must not be reduced to being desired by the lead.

- **C — Foundation:** Elianne was previously named first love. Lizzy is now confirmed as the Form One crush, Form Two girlfriend and Form Three breakup. Their identities must not be merged without clarification.
- **P — Distinct visual code:** Thoughtful school-era peer with neat braids, a ribbon, books and a deliberate way of holding a conversation. Her proposed ribbon and books distinguish her within the shared sky-blue/navy uniform. Earlier white/brown school concepts are superseded.
- **Performance:** Give her private wants, friendships, competence and boundaries before any romantic scene. Her attention cannot be a prize for Zino’s charm.
- **Continuity hold:** Keep this design provisional until Zino records when and how they met, her age then, what she wanted, and what the relationship changed.

---

# 03 — Zino’s family

**Visual sheet:** `images/03_Family.png`

### ZINO’S MOTHER

**Story role:** The person Zino most wants to provide for; a teacher whose work and faith in him make the dream concrete.

- **C — Foundation:** She raised Zino as a single mother after his father’s death, taught in primary school from a young age and throughout his childhood, believed in Zino, and carried household pressures alongside teaching.
- **P — Distinct visual code:** Upright posture, patterned teacher’s dresses, practical shoes, shoulder bag and a stack of marked exercise books. Warmth belongs in a private smile or a quiet touch, not in a softened version of her workload.
- **Performance:** She does not need raised volume to hold a scene. Let pauses, a corrected exercise book, a bucket set down carefully, and the decision to keep going carry her strength.
- **C — Trust:** Zino’s room is two apartments from hers. He could come, go or sleep late without her always knowing; she trusted him. This does not establish neglect or approval of everything he did.
- **Do not do:** Do not turn her into suffering alone. She needs humour, professional skill, friends, limits and a point of view that is not only about Zino.

### ZINO’S PATERNAL UNCLE

**Story role:** An intermittent financial support, a proud witness to Zino’s academic achievement, and the source of a promise that changes shape.

- **C — Foundation:** He helped with school fees from time to time. Proud of Zino’s Ordinary-Level results, he promised Zino could choose any school and go to America if he passed all five Advanced Levels. After Zino completed them, the uncle deferred America until after Zino earned a first university degree.
- **C / P — Visual correction:** He is a renowned lawyer known for suits, later a Christian convert and cocoa trader with a large Kumba store by Form Three, shipping trailers to Douala. The revised illustration shows a charcoal lawyer-era suit; later store/dispatch clothing remains open.
- **Performance:** Pride can coexist with constraint. Do not play the promise’s deferral as cartoon betrayal until Zino provides the uncle’s reasons and the actual conversation.
- **Continuity hold:** Name, conversion date, legal/trading overlap, family circumstances, exact contributions and motive for the deferral remain open. His profession is now supplied.

### ZINO’S FATHER

**Story role:** A loss Zino inherited rather than remembered.

- **FT — Foundation:** Zino’s father died from a snake bite while spraying cocoa when Zino was two. Family testimony says he cut the area and tried to suck the venom before passing out and dying before reaching home. Zino has no direct recollection.
- **P — Visual treatment:** Use only a respectful framed photograph, family-told memory or restrained symbolic image until a relative’s account and any real visual reference are supplied. The current visual sheet’s cocoa-farmer portrait is nonliteral.
- **Performance / writing rule:** Never give him remembered dialogue or a first-person flashback from Zino’s point of view. His absence should be felt in family stories and in the life it left behind.
- **Do not do:** Do not show the injury for spectacle or invent his personality, voice, fault or final moment.

---

# 04 — School and compound adults

**Visual sheet:** `images/04_School_and_Compound_Adults.png`

### MISS MUKETE

**Story role:** Zino’s favourite chemistry teacher and a potential adult who sees his academic strength clearly.

- **C — Foundation:** Miss Mukete is Zino’s favourite chemistry teacher. No additional biography, speech patterns, physical description or classroom memory has been confirmed yet.
- **P — Distinct visual code:** Gold-rimmed reading glasses, neat low natural hairstyle, blue patterned blouse under a white lab coat, a chemistry notebook and a small beaker. Blue, chalk white and glass reflections separate her from the more earth-toned Fiango palette.
- **Performance:** Precise, observant and encouraging. She should demand work without becoming a generic inspirational teacher.
- **Continuity hold:** Her likeness, age, exact school, chemistry routines and relationship with Zino need his memories before an episode gives her a personal storyline.

### THE LANDLORD

**Story role:** The recurring face of monthly rent and electricity pressure in the compound.

- **C — Foundation:** The Fiango compound contains two families, three single mothers, two bachelors and three student tenants. The landlord comes each month to collect house rent and electricity money.
- **P — Distinct visual code:** Lean older man, silver at the temples, pale short-sleeve shirt, dark trousers, leather sandals, keys and a well-used ledger. His measured face lets the audience read the money pressure without claiming he is cruel.
- **Performance:** Brief, factual, unshowy. He belongs to the compound’s economy, but his own circumstances have not been supplied.
- **Do not do:** Do not make him a villain, establish his motives, invent an amount owed or present a specific rent confrontation as fact.

---

# 05 — Reserved characters: do not visually lock yet

| Character / group | Confirmed foundation | Needed before visual design or a major scripted scene |
| --- | --- | --- |
| **Maternal aunt** | She cooked for and supported Zino, believed in him, and was later attacked and killed. | Her name, age, relationship history, date/place/context of death, visual reference, and which memories Zino directly holds. |
| **U.S. girlfriend** | Zino identifies a girlfriend during the America years. | Name or fictionalization choice, her perspective, years together, what the relationship changed, and consent boundaries. |
| **Boarding-school peers, teachers and priests** | School had elite students, wealthier parents, white teachers and priests, bullying and strict discipline. | Names, individual roles, actual incidents, and visual references; avoid creating composites that turn a social environment into one identifiable person. |
| **Football friends / crypto circle** | Zino pitched Nkap and njangi.xyz to football friends. He believes friends later reported him to immigration and sought to take the work. | Names or fictionalization plan, ownership record, what each person actually did, and a defensible account before visualizing alleged wrongdoing. |
| **Chinese online-retailer colleagues in Dubai** | In 2020 Zino moved to Dubai and worked for a Chinese online retailer of digital products. | Names, work function, workplace layout, colleague perspectives, and permission/factual boundaries. |
| **University and immigration characters** | Zino studied in Oklahoma beginning 2012, experienced money, papers, loneliness, racism and relationship pressures, then was deported in 2019. | Names, dates, events, documents, and any fictionalization plan before new characters appear. |

## Cast-wide production rules

1. Keep every visual difference tied to character action: Zino moves first, Gideon scans, Luc squares himself, Mother holds the room, Uncle weighs, Miss Mukete observes, and the Landlord records.
2. Preserve the supplied compound and Grand-Chukuchuku references as visual authorities. New clothes, age variants and locations may evolve, but Zino and Grand retain their family resemblance.
3. A proposed physical feature is a production choice, not a claim about a real person. Replace it when Zino supplies a real reference, correction or fictionalization direction.
4. Do not stage the father’s death, the aunt’s killing, or the alleged immigration report as fact until source details and the appropriate point of view are established.


---

# GRAND-CHUKUCHUKU
## Fiango — daily life, neighbourhood and character update

**Source:** Zino's recollections supplied on 30 October 2026.  
**Authority:** This update supersedes conflicting proposed details in the earlier character bible, scripts and concept art.  
**Key:** C = author-supplied recollection; P = proposed dramatic or visual treatment; OPEN = not yet settled. No suggested scene is a claimed transcript.

## 1. A weekday has its own ticking clock

### 5:30 a.m. — the cocks behind his room

**C:** Zino wakes to cock-crowing behind his room around 5:30. Four buckets come before school: two rounds to the well, one full bucket in each hand on each return.

**P — screen treatment:** Begin with sound in darkness, then a low shot of two bucket handles pulling down on his hands. The first round is not the last. A wide shot establishes the actual route from his detached room to the shared well. This can show fatigue, humour and household duty before anyone explains poverty.

### The bathroom queue

**C:** Tenants share two bathrooms. Zino waits his turn. Feet and lower shins are visible under the short door, telling someone outside that it is occupied.

**P — screen treatment:** Show only closed doors and feet from the ordinary queue's viewpoint. An impatient toe tapping outside answers still feet inside. No camera enters an occupied cubicle; there is no nudity. Whether this exact door detail applies to bathrooms, toilets or both remains open.

### Two rooms, not one

**C:** Zino has his own room, two apartments detached from his mother's room toward the front. Her room contains a queen-size bed and a drawer beside it. After getting ready for school, he enters her room to check the money left in that drawer.

**C — later addition:** Mother trusts him. The separation between their rooms means he can come and go or sleep late without her always knowing. This is freedom within their particular living arrangement; it does not establish neglect, permission for every activity, or her constant absence.

**P — screen treatment:** The route between rooms creates private and public space: he must pass other tenants before reaching Mother. Do not invent a locked door, secret drawer, missing cash or theft. Checking the money is his routine, not automatically a suspicious act. Exact room dimensions and the age at which this arrangement began are open.

### The 200-CFA decision

**C:** Usually two coins totalling 200 CFA are left for school. He can use 100 for transport and spend 100 at school. If he gets ready early enough to walk, he can keep the 200 for school. Earlier recollections establish that he sometimes saves lunch money for Nacking Bottle.

**Clarified:** a single taxi ride costs 100 CFA from the pickup to school, on three mornings per week. It is not three connecting rides. Two coins totalling 200 are confirmed; exact denominations need not be drawn. Exact weekdays and travel time remain open.

**P — dramatic engine:** Time, effort, hunger and football all draw on the same small budget. A late bathroom queue can change his transport decision. An early start can buy a better school day. That is a real choice; it does not need an invented criminal threat.

## 2. The TV window and the neighbourhood

**C:** Beside the compound, a household has a large TV. Zino and other children stand outside a steel-barred window to watch. Later Ayuk's father buys a TV, and Zino watches sport and films inside Ayuk's home, one house from the compound, sometimes until 9 p.m.

**Clarified:** 'college' means the five secondary day-school years. Ayuk's TV belongs in that period; the exact form/year is still open. Programme titles, TV model, power reliability and the owner's treatment of the children remain unconfirmed.

### Relative locations supplied

- **Ayuk:** a house north of Zino's compound; later also described as one house away.
- **Arey:** Ayuk's cousin. A separate house or sleeping arrangement has not been supplied.
- **Noge:** lives next to Ayuk's house; east or west is unspecified.
- **Bismark:** south, next to the TV house.
- **Robi:** next to Bismark; a compass side is unspecified.
- **Original TV house:** adjacent to the compound; do not infer a precise compass side from the other relationships.
- **Taxi pickup / major road:** a tarred road five houses behind the compound. 'Behind' is not yet a compass bearing. Travel time is unconfirmed.
- **Azi Motel:** a nearby five-storey motel. Do not turn the building name into a verified street address.
- **Mother's aunt's home and poultry farm:** next to Azi Motel, supplying poultry directly to it and other hotels. This is Zino's great-aunt, distinct from the maternal aunt later killed. 'Poetry/peotry' is interpreted as poultry from context.

The companion diagram is an adjacency schematic, not a surveyed map. The supplied compound image remains a material/visual reference; it cannot overrule the author's new room, bathroom or neighbour details.

## 3. The football circle — corrected

**C:** Zino's street-playing circle includes Ayuk, Arey, Noge, Bismark and Robi. The author describes them as the same age group and class. Luc and Gideon do not play.

### Zino

Plays. His ambition, skill, pride and temper can all surface in one ordinary street match. Do not infer that he is always the best player or always wins.

### Ayuk

**C:** A neighbour north of the compound, a class/age peer and a football participant; his father's later TV makes his home part of the group's evening world. **P — design proposal:** an easily read straight-backed silhouette and a cobalt accent distinguish him from Gideon's olive. Hair, body shape, exact clothing and personality await references.

### Arey

**C:** Ayuk's cousin and a football participant in the same circle. **P — design proposal:** a distinct side-part silhouette or rust-coloured sleeve stripe can separate the cousins. Do not make him Ayuk's visual double or invent a rivalry.

### Noge

**C:** Neighbour next to Ayuk, class/age peer, football participant. **P — design proposal:** an open, square stance and one pale-yellow clothing accent. No position, temperament or football skill is yet confirmed.

### Bismark

**C:** Lives south, next to the TV house; a player and peer. **P — design proposal:** a longer shirt silhouette and one maroon accent. His home position does not establish that he owns the TV or polices access.

### Robi

**C:** Lives next to Bismark, a player and peer. **P — design proposal:** a compact, forward-leaning pose and a muted turquoise accent. These are staging ideas, not a real physical description.

### Gideon — the sideline voice

**C:** Does not play. He sits watching and bantering with Zino, particularly when Zino loses. His camera work, business interests, quietness with girls and friendship with Zino remain intact. He constantly finds gigs, sells things or exchanges services for money. By Form Five he has a place in the market selling bread. He also turns to Zino to explain schoolwork. Zino calls him **Giddy**; the canonical name is **Gideon**, including when the author's message says Gideo.

**C — visual correction:** W-shaped hairline and fuller, almost-afro hair replace the earlier generic short-cropped proposal. Exact hair length at individual ages remains open. **Correction:** earlier goalkeeper, scoring teammate and demanding-a-pass scenes are superseded. His humour can puncture Zino's public performance without making their friendship cruel.

### Luc — a different use for the same evening

**C:** Does not play. He spends time evangelising or chatting. His small Bible and Zino's maths help remain part of their friendship. He lifts weights in the evenings, using homemade mud-formed dumbbells, and has a sand-filled punching bag. He has a muscular, bodybuilder-like build and a high flat-top haircut. Zino calls him **Lucky Luc** when he encounters him by himself.

**C / OPEN — visual correction:** The earlier lean/slender design is superseded. His training's starting age and changes in physique across the school years are not supplied. Keep child proportions at ten; do not back-project an adult bodybuilder's anatomy onto the opening. **Correction:** do not automatically make him a referee, scorer or touchline commentator in every match; he may be having an entirely separate conversation nearby. Exercise, conversation and preaching need not all occur on the same evening.

## 4. School relationships — keep their timelines distinct

### Lizzy

**C:** Zino's crush in Form One, girlfriend from Form Two, breakup in Form Three. The author corrected his earlier Form Four statement. He recalls her going with an older student who had money.

**OPEN:** Elianne, previously named first love, is not automatically Lizzy, an alias, or a character to delete. Lizzy's school timeline is now resolved; Elianne's separate place still needs explanation.

**P — character treatment:** School-age affection, conversation, jealousy and hurt can carry the relationship. Give Lizzy her own perspective. Zino's account of money and the older student is his recollection, not a licence to invent every motive or turn her into a villain.

### Mirabel

**C:** Friendship begins in Form Three because of Zino's brilliance in maths and continues until he leaves for America. **P — character treatment:** a friendship that can outlast classrooms and physical distance. Proposed visual marker: a geometric notebook cover, careful underlining and a distinct hair silhouette once references arrive. Do not infer romance, jealousy or a love triangle.

### Sophy

**C:** Gideon is in love with her from Form Two to Form Five. Zino recalls her as attractive and interested in money; she makes repeated advances toward him, and he turns her down out of loyalty to Gideon.

**P — character treatment:** Express interest through conversation, chosen company and expectations about spending. Keep her school-age design and camera framing nonsexual. Do not caricature her body or treat her as inherently dishonest. Proposed design marker: a neat, deliberately coordinated school bag or hair accessory, not sexualised clothing.

### Tracey

**C / OPEN:** An older student who attends the night-study space. Zino reports his first sexual experience with her while in Form Three, described as after the Lizzy breakup. Both ages, the precise ordering and the circumstances still need his account.

**C — later addition:** She has already sat the GCE twice without passing. She sees Zino teaching maths to students who subsequently pass the GCE. This gives her an academic connection to the study space; it does not establish her exact age, private motives, a transaction, or that Zino alone caused anyone's examination result.

**Treatment:** Preserve the disclosure in neutral biographical notes. Do not script or illustrate an explicit sexual scene involving school-age Zino. If later included, use a non-graphic transition and his own description of its emotional meaning. Do not invent adult status, consent, coercion, culpability or a relationship label. No seductive character art is requested or needed for this update.

### School uniform and working ages

**C:** All students wear light sky-blue short-sleeved shirts. Boys wear dark-blue trousers; girls wear dark-blue skirts. Earlier white/cream/brown school palettes are superseded. Distinguish characters through faces, hairstyles, posture, bags and books rather than changing the uniform colour.

**P — ages authorized as estimates:** Form One about 10–11, Form Two 11–12, Form Three 12–13, Form Four 13–14, Form Five 14–15, using the approximate 2000–2005 day-school chronology and 1990 birth year. Exact birthdays and enrolment dates are not supplied. The author describes similar-age peers; Tracey being older does not establish that she was an adult.

## 5. Uncle — the suit, faith and cocoa

**C:** A renowned lawyer known for wearing suits. After giving his life to Christ, he becomes a cocoa businessman. By Zino's Form Three year he opens a large cocoa store in Kumba, with trailers carrying cocoa to Douala. He loved his late brother, Zino's father, deeply. That brother had limited formal education and grew and sold cocoa.

**C — reported advice:** Uncle tells Zino to study hard so he does not end up like his father. This is the uncle's reported framing, not a narrator's judgement of farming or of the father. His grief, class assumptions and hopes for Zino can coexist.

**P — visual correction:** The old casual-shirt concept does not establish his lawyer-era wardrobe. Use structured suits for that period. A later store/dispatch look must follow the actual timing and references; do not assume conversion meant poverty, an end to suits, or an instant change in personality.

**Story opportunity:** Cocoa links the brothers without making their lives identical: one grew it, another traded it at scale. Uncle urging Zino to leave the father's path while building his own future in the same commodity is a complex family tension, not automatically hypocrisy.

**OPEN:** Did legal work stop or overlap with trading? When did he convert? Why was support intermittent despite his status? What did his America promise mean financially? Do not invent business collapse, withholding, family cruelty or the reason for late fees.

## 6. How to use this in a thriller series

The extraordinary events need an ordinary world worth losing. Suspense can grow from a specific choice and a visible consequence; every bucket, TV programme and friendship does not need a sinister score.

### Proposed three-act short seeds

1. **Four Buckets:** I — the cocks wake him and he wants an early start. II — two full rounds take work. III — the bathroom queue makes him calculate whether walking is still possible. Do not add a real accident without a memory.
2. **The Feet Under the Door:** I — Zino joins the queue. II — neighbours arrive with different schedules. III — his turn changes the morning's time budget. Keep framing outside occupied bathrooms.
3. **Two Coins:** I — the drawer contains 200 CFA. II — transport means spending half; walking costs time. III — choose one and carry that consequence into school.
4. **The Long Walk:** I — he leaves early enough. II — he passes ordinary neighbourhood activity. III — he reaches school with the money intact. Walking is a practical trade, not a magical cure for school fees.
5. **Gideon's Seat:** I — Zino needs a good game. II — Gideon narrates his mistakes from the sideline. III — Zino loses and must decide how to take a joke without turning on a friend.
6. **Two Evenings:** I — football attracts Zino. II — Luc finds someone willing to talk. III — their routes reconnect without either friend needing to imitate the other.
7. **Through the Bars:** I — children gather at the TV window. II — the view is narrow and a match or film matters. III — access becomes part of the pleasure and frustration. No invented ban or malicious owner is required.
8. **Ayuk's TV:** I — during secondary school, the group has a new place to watch. II — the evening grows late. III — 9 p.m. means home and tomorrow's 5:30 start. Exact form/year of purchase remains open.
9. **Mirabel's Sum:** I — a maths question starts a friendship in Form Three. II — mutual respect grows through repeated work. III — give her a response and an independent want; friendship need not become romance.
10. **Bro Code:** I — Gideon hopes Sophy will choose him. II — she approaches Zino instead. III — he refuses without publicly humiliating her or congratulating himself.
11. **The Store:** I — Zino sees his uncle's cocoa operation. II — the uncle urges education while work continues. III — Zino hears the reference to his father and carries a difficult question home. This is proposed staging; no warehouse visit is confirmed.
12. **Form Three:** I — Lizzy's connection with Zino matters. II — attention and money complicate it. III — the breakup happens in Form Three; record the exact sequence before adding Tracey's experience as an aftermath.

## 7. Corrections to carry into every active draft

- Luc and Gideon watch/socialise beside football; named street peers play. No invented trio team.
- Morning water is four buckets in two trips, one per hand; the new routine is not four separate trips.
- Separate bedrooms are two apartments apart; the illustration is not authority for a shared-bedroom scene.
- 200 CFA is the school allocation, not a fee amount or proof Mother left cash unattended for anyone to take.
- Taxi wording and the TV-era word are resolved by the author: three mornings a week, 100 CFA per ride; TV transition during secondary school. Do not invent the weekday pattern or exact purchase year.
- The new girls remain separate characters. Preserve Elianne until her identity/place is clarified.
- Father's cocoa work is a life and livelihood, not a failure verdict. Uncle's work and faith are now supplied facts, not generic mystery.
- The named childhood players have not been identified as the later crypto circle.
- Luc's muscular build and high flat-top supersede the lean design; Gideon's W-shaped hairline and almost-afro hair supersede the generic cropped-hair proposal. Keep age-appropriate versions rather than copying an older-school design unchanged onto ten-year-olds.
- Zino's own songwriting begins in Form Five, and his first demo follows his return home from boarding high school. Later writing in America continues that history; a draft implying that his music begins in America must change.
- The author's general GCE minimum pass thresholds, the maximum subjects available, Zino's own subjects and the school's pass rate are four different facts; none replaces another.

## 8. Questions awaiting Zino's corrections

1. Elianne's identity/place remains open. Lizzy's breakup is now fixed in Form Three.
2. Taxi frequency/fare is resolved. Exact weekdays and journey length remain open.
3. The TV era is secondary school. What form/year did Ayuk's father get the TV?
4. How old were Zino and Tracey? Record the experience in his own terms before assigning a label or dramatizing an aftermath.
5. From which age/form did Zino have the separate room, and are the feet-visible doors bathroom doors, toilet doors or both?
6. What is the sequence of the uncle's conversion, legal work and cocoa-store operation, and why were school payments sometimes late?

## 9. Latest character and education additions — 30 October 2026

### Zino — understanding, music and faith

**C:** He quickly understands scientific concepts, with maths his favourite subject. He describes maths as easy, like a puzzle: he can work out an answer instead of doing the kind of reading he associates with History, Geography and Literature. This describes his preference and confidence, not illiteracy, lack of effort or an inability to learn other subjects.

**C:** He loves singing and starts writing his own songs in Form Five. He records his first demo after coming home from the two-year boarding high-school period. His later songwriting in America is a continuation.

**P / OPEN — placement:** On the existing working chronology, Form Five is around 2004–2005 and the first demo is after his high-school return around 2007. These are approximate placements, not newly confirmed recording dates. Demo title, collaborators, studio, cost and exact timing remain open. Do not place a completed demo in the earlier Fiango day-school years.

**C:** Zino is Catholic and serves at Mass throughout primary school. Secondary-school demands leave him without time to continue altar service. Reduced service is not evidence that he abandons his faith or becomes Luc's religious opposite.

**P — character use:** Let confidence in a maths problem sit beside a song idea he is still struggling to express. Faith can appear through an ordinary practice or memory when its timing is supported. Invented lyrics, lessons and dialogue remain dramatic proposals, not recovered testimony.

### GCE — keep four measures separate

**C — author's account of the examination system:** A paper means a subject in this account. The minimum pass threshold is four subjects at Ordinary Level and two at Advanced Level. These are the author's supplied rules for the story; historical regulations have not been independently verified here.

| Measure | Ordinary Level | Advanced Level |
| --- | --- | --- |
| General minimum pass threshold supplied by the author | 4 subjects | 2 subjects |
| Maximum subjects supplied by the author | 11 subjects | 5 subjects |
| Zino's reported subjects | 10 subjects | 5 subjects |
| His boarding school's reported pass rate | Not supplied | 100% |

The uncle's promise specifically depends on Zino succeeding in all five Advanced-Level subjects, a higher condition than the author's general two-subject minimum. The school's 100% pass rate does not mean every student takes or passes five subjects, and it supplies no Ordinary-Level school statistic.

### Friendship, work and trust on screen

**C:** Luc's weights and punching bag belong to his evening life. Gideon's market bread place belongs by Form Five; earlier camera work, small trades and paid services precede or coexist with it as the author describes. His quietness with girls does not make him passive about business. Zino's maths help extends to Gideon as well as Luc and other students.

### Three-act short seeds — proposed

1. **Lucky Luc:** I — Zino finds Luc training alone. II — a conversation competes with the next set of homemade weights. III — the nickname lands in a private friendship moment. Place at an age consistent with the eventual training chronology; do not invent a dangerous stunt or athletic victory.
2. **Giddy's Bread:** I — in Form Five, Gideon must give attention to a customer at his market place. II — he brings Zino a schoolwork problem between tasks. III — business confidence and academic uncertainty share the same character. Exact prices, takings, ownership terms and Zino's presence there are proposed or open.
3. **The First Song:** I — Form Five Zino begins a lyric. II — a melody resists the easy certainty he finds in maths. III — he keeps working. Save the first recorded demo for after boarding high school; do not invent an instant music career.

**OPEN:** When did Luc begin training, and how did his build and haircut change? What did Gideon's market arrangement involve? Which school year did each nickname start? What was the first song and where was the demo recorded? These gaps do not block the confirmed traits, but they limit precise scene dates and props.
