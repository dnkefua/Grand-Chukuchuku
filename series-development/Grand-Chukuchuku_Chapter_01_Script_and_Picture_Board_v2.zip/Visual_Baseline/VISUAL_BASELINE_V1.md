# GRAND-CHUKUCHUKU — Visual Baseline v1

## GBHS campus and badge addition — 31 October 2026

**C:** Day school is Government Bilingual High School Kumba (GBHS), reported 10.7 km from Zino's compound. Forms One–Two: one storey; Form Three, Four–Five and Lower/Upper Sixth: two storeys. The author resolved the initial Form Three ambiguity. GBHS Sixth Form does not replace Zino's separate boarding school; Professional School remains a distinct location.

Use [`../school-campus/campus_spec.json`](../school-campus/campus_spec.json) and the labelled plans for reported relationships and proposed geometry. Six native campus images are photorealistic **design reconstructions**, with proposed materials, terrain, orientation and footprints. They do not establish actual architecture, survey distances or travel time. The second 500 m span includes labs/canteen locally; exact distance endpoints remain open.

**C:** Sky-blue day-uniform shirt has a pocket on the **wearer's left chest**, viewer-right frontally. Round badge: **GBHS**, circular **Government Bilingual High School Kumba**, lit candle centre. Use the [badge construction reference](../school-campus/references/GBHS_Badge_Construction.pdf) for exact text. Colours/typography/candle art are **P**, not verified official crest details. No back badge or badge on night casual clothes. Updated Mirabel/Lizzy uniform sheets and the core friend portrait supersede their unbadged copies; earlier scene images remain historical concepts.

These two author-supplied images are the canonical visual references for all new or revised storyboards, character art, image-generation prompts, animation turnarounds and colour scripts.

| Reference | Location | What it locks |
| --- | --- | --- |
| **Courtyard / compound** | [`Courtyard well inside the compound.png`](../../Courtyard%20well%20inside%20the%20compound.png) | The Fiango compound's open circular court, mature mango tree, masonry well, close-set low homes, rust-red corrugated roofs, tropical planting, red-earth road, boundary wall and overhead power lines. The foreground also establishes the everyday scale and materials of Professional School. |
| **Grand-Chukuchuku model sheet** | [`Grand Chukuchuku main character sheet.png`](../../Grand%20Chukuchuku%20main%20character%20sheet.png) | Grand-Chukuchuku's adult silhouette, short tapered curls, close beard, warm brown complexion, navy suit, open white shirt, brown shoes, and expressive range: knowing, steady, doubtful and joyful. |

## Character continuity

Grand-Chukuchuku is Zino's adult, idealised invention. He should look composed, well dressed and physically grounded—the man Zino imagines he could become, not a superhero costume. His confidence comes from posture, eye-line and a quick smile.

Ten-year-old Zino is a younger real-world counterpart, not a shrunken copy of the adult model. Preserve the family resemblance through the hairline, brow, eyes and smile, while keeping his clothes, proportions and movement appropriate to his age and Fiango street football. Grand-Chukuchuku appears with richer navy, gold and cream accents; Zino's real world remains red earth, sun-faded fabric, school sky blue/navy and compound greens.

## Environment continuity

The courtyard is the Chapter One home base. Frame the mango tree and well as the social centre whenever the compound is seen wide. Let the clustered homes, laundry, buckets, cooking, rent-day quiet, neighbours and football reshape the same space over time. Keep the red-dirt road, roof texture, dense green perimeter, wall and power lines in exterior transitions.

Professional School must retain a practical, lived-in building/construction/electrical character. Its classrooms can become night revision spaces, but the compound reference is the authority for the surrounding town texture, daylight palette and spatial density.

## Board rule from 28 October 2026

The existing Chapter One picture-board panels remain valid for dramatic framing. Any new panel, replacement, animation asset or render must start from these two references. When an older panel conflicts with this baseline, the baseline wins.

## Character-bible handoff from 29 October 2026

[`../character-bible/Grand-Chukuchuku_Character_Bible_v1.pdf`](../character-bible/Grand-Chukuchuku_Character_Bible_v1.pdf) adds production-ready, **proposed** visual signals for Gideon, Luc, Elianne, Zino's mother, paternal uncle, Miss Mukete and the landlord. It also preserves the father as a nonliteral family-memory treatment and holds later cast designs until source details arrive. The character bible extends this baseline; it does not replace author-supplied real references or convert any proposed feature into biographical fact.

## Author corrections — 30 October 2026

- The current character bible is [v2](../character-bible/Grand-Chukuchuku_Character_Bible_v2.pdf), with the [daily-life and character update](../character-bible/Fiango_Life_and_Characters_Update_2026-10-30.md). Its author-supplied facts supersede earlier proposed wardrobe and character action.
- **Forms One–Five daytime uniform:** light sky-blue short-sleeved shirts; dark-blue trousers for boys, dark-blue skirts for girls. Older white/cream/brown daytime school art is a superseded concept. Boarding uniform is unconfirmed. Night revision, casual football clothes and Grand's adult suit follow separate rules.
- **Football:** Luc and Gideon do not play. Gideon sits and banters; Luc evangelises or chats. Ayuk, Arey, Noge, Bismark and Robi play with Zino. Daytime school uniforms do not distinguish the trio by shirt colour; use faces, posture, camera bag and Bible. Casual night-study outfits can distinguish them without changing the daytime uniform.
- **Compound layout:** Zino's room is two apartments from Mother's front room; two shared bathrooms have short doors showing feet/lower shins. These details override assumptions drawn from a picturesque courtyard reference. The reference controls materials and mood, not a measured floor plan.
- **Uncle:** lawyer-era suits are confirmed; the earlier casual-shirt drawing is not authority for that era. Later cocoa-store dress remains open.
- **Neighbourhood:** the tarred pickup road is five houses behind; Azi Motel is five storeys; Mother's aunt has a poultry business next to it. Treat the new adjacency schematic as relationships, not surveyed distances or compass bearings.

## Later character corrections — 30 October 2026

The following are **C — author-supplied features**, superseding earlier **P — proposed** designs. Costume and pose choices not supplied by the author remain proposals.

- **Luc:** muscular, bodybuilder-like build from lifting weights in the evenings; high flat-top haircut. Homemade mud-formed dumbbells and a sand-filled punching bag belong to his training world. The earlier lean/slender design is superseded. Training onset and changes across the school years are **OPEN**: the opening at ten must keep child proportions, rather than copying adult-bodybuilder anatomy. His Bible, evangelism and non-player football role remain.
- **Gideon / Giddy:** W-shaped hairline and fuller, almost-afro hair replace the generic cropped-hair proposal. Camera/bag remains useful for school-era identification. A bread-selling market place belongs by Form Five; do not put a bread stall into his earlier scenes without a date. Exact stall design, ownership terms and physical maturity at each age are **OPEN**.
- **Zino:** the existing likeness remains. Science and maths aptitude, singing, Catholic identity and primary-school altar service are behavioural/contextual facts, not permission to add unconfirmed uniforms, religious jewellery or instruments. Original songwriting begins in Form Five; the first recorded demo belongs after his boarding high-school return. Later American music is a continuation.
- **Rooms and trust:** Mother's trust and the separate room explain scope for unobserved coming/going. Preserve the actual two-apartment separation without inventing a deserted home, a neglectful mother or evidence that she approves every event.
- **Tracey:** two unsuccessful GCE attempts and observing Zino's maths teaching add academic context. Neither settles age or private motives. No sexualised school-age character design or explicit scene follows from these facts.

**P — age progression rule:** a single character sheet should not silently fix one physique or hair length across seven school years. The latest features guide revised older-school portraits; label opening-age variants and leave training/hair progression open until the author supplies dates.

## Night wardrobe and turnaround correction — 30 October 2026

**C — night revision:** no student at Professional School's night sessions wears a school uniform. Students wear regular house/casual clothes; some dress to impress. The prior blue-shirt night-study pilot images and uniform instruction are superseded. The correction does not change the daytime uniform or establish boarding colours.

**P — pilot clothing continuity:** Zino: burgundy plain short-sleeved T-shirt, charcoal casual trousers; Gideon: forest-green polo, dark-brown casual trousers, camera bag; Luc: mustard/ochre T-shirt, loose navy casual trousers, Bible. Carry these proposed outfits from night study through the road and homecoming, including the cold-open and final well close-ups. Background night students also wear varied casual clothing; adults remain in their own civilian clothes. Grand's navy suit is unchanged.

**C — additional visual traits:** Zino is handsome with clean fades. Luc has large hands and ears as well as his trained build/high flat-top. Gideon has a large head, prominent nose and small front-tooth gap, alongside his W-shaped hairline and fuller almost-afro. Mirabel is beautiful and slim; Lizzy has a pretty face. Canonical spellings remain **Gideon** and **Mirabel**, treating 'Giddeon' and 'Mirable' as variants.

**P — five-character model set:** `../character-bible/turnarounds/` contains front, left-side and back model sheets for Zino, Luc, Gideon, Mirabel and Lizzy, with matching scale, clothing and neutral poses across views. These are later-secondary working designs around fourteen–fifteen, not real likenesses or age-ten models. **C:** Mirabel and Lizzy are Black girls with low-cut natural hair. Exact crop texture/hairline, facial construction and casual garments remain proposed. Use ordinary clothing and natural adolescent proportions. Keep them distinct from the provisional Elianne portrait.

**Latest correction / replacement:** both girls have low-cut natural hair; earlier bob/puff/braided-back proposals are superseded. Mirabel is darker than Lizzy, as confirmed on 31 October. Her proposed angular oval face/straight brows and slim outline differ from Lizzy's rounder face/arched brows and current broader silhouette. Exact shades, crop styling, faces and garments remain proposals. The new `../character-bible/turnarounds/school-uniforms/` sheets test these identifiers in matching sky-blue shirts/navy skirts. Do not invent long hair or different uniform colours to distinguish them.

**Implementation status:** Mirabel's darker complexion is applied to casual and uniform models. Lizzy's body-size edit was declined and not applied; her casual source is unchanged, and the uniform model changes clothes only. Latest actual-asset review: `../writers-room/COMPLEXION_AND_UNIFORM_REVIEW_2026-10-31.md`.
