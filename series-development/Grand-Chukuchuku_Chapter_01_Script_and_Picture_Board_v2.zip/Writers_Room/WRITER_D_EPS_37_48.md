# GRAND-CHUKUCHUKU — Chapter One / Fiango

## Writer D draft — Episodes 37–48

**Season format:** 60 vertical episodes; every episode is 1:35–2:00.  
**Block:** the end of Fiango day school, the O-Level threshold, and Zino's first boarding-school year.  
**Draft rule:** **C** = confirmed recollection; **FT** = family testimony; **R** = reported or incomplete; **P** = proposed composite. Every exact line, gesture, setting order and scene construction below is P unless marked otherwise.

**Block movement:** These episodes do not rush from a result into boarding. They let revision, waiting, a promise, travel, routine, social difference and loneliness change Zino one short decision at a time. Grand-Chukuchuku only appears when Zino deliberately tells a story or hides a fear.

---

# EPISODE 37 — “TEN ON THE TABLE”

**Runtime:** 1:55  
**Logline:** Zino wants ten O-Level subjects to look like a plan; the number becomes frightening once the papers are finally in front of him.  
**Fact tier:** **C** — after five Fiango day-school years, Zino wrote 10 GCE Ordinary-Level subjects; the maximum was 11. **P** — revision arrangement, paper order, dialogue and individual study images.

### 0:00–0:18 — THE NUMBER
**VISUAL | C fact / P staging:** *c. 2005 — END OF FIANGO DAY SCHOOL.* Ten subject labels fill the frame, beside one unmarked place on a general list of eleven. Do not explain why Zino chose ten.

**SOUND:** Pencil sharpened; distant football on red dirt.

### 0:18–0:55 — EACH ONE HAS WEIGHT
**VISUAL | P:** At the compound table, Zino moves between papers instead of making a Grand-Chukuchuku story. His mother marks her pupils' books nearby, hears him recite a point, then points back to the line he skipped.

**MOTHER (P):** Read the question before you answer am.

### 0:55–1:30 — FRIENDS PASS THROUGH
**VISUAL | P:** Gideon crosses the courtyard with his camera bag; Luc passes with his small Bible under an exercise book. Neither interrupts. The football sits near Zino's chair, unused.

**ZINO (P, to the ball):** Today you rest.

### 1:30–1:55 — HOOK
**VISUAL | P:** Zino places all ten papers in one stack, then switches off the compound light over the table when his mother tells him it is late.

**END CARD:** *EPISODE 38 — THE LAST BELL*

**Fact boundary:** No subject name, grade, exam room, exam date or reason for the eleventh unchosen paper is established.

---

# EPISODE 38 — “THE LAST BELL”

**Runtime:** 1:50  
**Logline:** Zino wants to leave the final O-Level paper feeling certain; the silence after the bell gives him no answer.  
**Fact tier:** **C** — Zino wrote 10 O-Level subjects. **P** — final paper order, room, invigilator, images, dialogue and Zino's response.

### 0:00–0:20 — NO MORE ROOM
**VISUAL | P:** An exam paper fills the vertical frame. Zino's eyes move from question to answer. Keep the subject and exact prompt unidentified.

**SOUND:** Pens; a wall clock; a chair leg scraping.

### 0:20–0:58 — THE TEMPER TEST
**VISUAL | P:** Zino catches himself racing. He nearly writes a clever shortcut, remembers his mother's rule, and works each step. He does not look for a reaction from another student.

### 0:58–1:28 — THE BELL
**VISUAL | P:** The final bell cuts through the room. Zino puts down his pen, presses his palm over the paper once, and leaves with no triumphal music.

### 1:28–1:50 — HOOK
**VISUAL | P:** Outside, Gideon points his camera at the exit. Zino steps aside before the shutter, not ready to be made into a result.

**END CARD:** *EPISODE 39 — STATIC*

**Fact boundary:** The post-exam gathering and camera framing are proposed; do not claim Gideon photographed an actual result day.

---

# EPISODE 39 — “STATIC”

**Runtime:** 1:45  
**Logline:** While Fiango waits for O-Level names on the radio, Zino discovers that waiting can be harder than any paper.  
**Fact tier:** **C** — GCE results were read on radio; students found the wait intensely stressful; there were no smartphones. **P** — radio location, who waits, dialogue and elapsed days.

### 0:00–0:20 — NO SCREEN TO CHECK
**VISUAL | C period fact / P staging:** A radio dial is tuned, lost, then tuned again. A school notice board stays blank. Zino passes it twice in the same day.

### 0:20–0:52 — FIANGO KEEPS MOVING
**VISUAL | P:** Children argue over football stones. A bucket rises from the well. Zino watches, unable to join the game. The everyday sounds make his waiting louder.

**GIDEON (P):** You fit worry radio until e talk?

**ZINO (P):** Try me.

### 0:52–1:20 — LUC'S DIFFERENT ANSWER
**VISUAL | P:** Luc folds his Bible shut instead of preaching. He offers Zino a pencil to occupy his hands. Zino begins a Grand-Chukuchuku story, then stops before the hero appears.

### 1:20–1:45 — HOOK
**SOUND | C mechanism / P staging:** A nearby radio suddenly clears. An announcer begins reading names, still too distant to hear.

**END CARD:** *EPISODE 40 — HIS NAME*

**Fact boundary:** No result list, radio station, listener group or exact period of waiting is claimed.

---

# EPISODE 40 — “HIS NAME”

**Runtime:** 2:00  
**Logline:** Zino wants the radio to say his name; when it does, the joy belongs to everyone who waited with him.  
**Fact tier:** **C** — Zino heard his O-Level result called on radio; the result made his uncle proud. **P** — location, audience, physical celebration, dialogue and sound arrangement.

### 0:00–0:22 — THE LIST
**VISUAL | C mechanism / P staging:** The radio is close enough now. Names cut through static. Every name before Zino's makes the frame tighter on his face.

### 0:22–0:57 — RELEASE
**SOUND | C result / P staging:** The announcer calls Zino's name. The response is immediate but not specific: hands reach into frame, a laugh catches, the radio is nearly knocked from its place.

**VISUAL | P:** Mother finds Zino's eyes first. Gideon lets out the shout he had swallowed. Luc smiles before he remembers to look serious.

### 0:57–1:33 — NOT A FANTASY
**VISUAL | P:** Zino holds the radio as if it could take the name back. Grand-Chukuchuku is absent. Zino has no need to invent a win.

**ZINO (P):** You hear am?

**MOTHER (P):** I hear you.

### 1:33–2:00 — HOOK
**VISUAL | C uncle pride / P staging:** Zino's uncle arrives or is revealed nearby only if the remembered arrangement supports it. He studies Zino with quiet pride before speaking.

**END CARD:** *EPISODE 41 — THE OFFER*

**Fact boundary:** Do not give Zino grades, a rank, a school result percentage, specific food, church scene, music or a fixed celebration location.

---

# EPISODE 41 — “THE OFFER”

**Runtime:** 1:55  
**Logline:** Zino wants his uncle's pride to mean something practical; the offer opens a road that comes with a harder condition.  
**Fact tier:** **C** — after Zino's O-Level result, his paternal uncle promised he could choose any school and go to America if he made all five A-Level papers. **P** — exact meeting, wording, reaction and dialogue.

### 0:00–0:20 — PRIDE WITH HISTORY
**VISUAL | C support / P staging:** The uncle's presence follows the irregular fee support already established in the season. There is no invented cheque, cash handover or repayment account.

**UNCLE (P):** You make me proud.

### 0:20–0:56 — THE CONDITION
**VISUAL | C promise / P dialogue:** The uncle speaks the offer in proposed words. Zino hears both permission and the challenge.

**UNCLE (P — replace with remembered wording):** Choose the school you want. Make all five Advanced-Level papers. America go follow.

### 0:56–1:28 — THE WORD HE HOLDS
**VISUAL | P:** The word *America* is not illustrated as a fantasy skyline. Zino looks at a spread of unnamed school options, then back at his mother. She does not choose for him.

### 1:28–1:55 — HOOK
**ZINO (P):** I know one school.

**VISUAL | P:** He circles a boarding-school option without showing a name, address or fee.

**END CARD:** *EPISODE 42 — THE SCHOOL HE CHOSE*

**Fact boundary:** The promise and the choice are confirmed. The exact words, reason, school list, mother's response and uncle's means remain open.

---

# EPISODE 42 — “THE SCHOOL HE CHOSE”

**Runtime:** 1:50  
**Logline:** Zino chooses distance because it looks like the road to America, and learns that choosing a dream also means leaving his daily world.  
**Fact tier:** **C** — Zino chose to change schools for remote boarding high school after the O-Level promise. **P** — preparation, farewell gestures, dialogue and visual detail.

### 0:00–0:22 — WHAT HE LEAVES
**VISUAL | C setting / P staging:** The compound's mango tree, well and red-dirt football space appear in quick, ordinary details: bucket, slippers as goalposts, camera strap, Luc's Bible.

### 0:22–0:54 — A CHOICE, NOT A FLIGHT
**VISUAL | P:** Mother asks Zino to put only needed things into a bag. He tries to add the football. She lets him decide; he sets it back down.

**MOTHER (P):** You choose this place. Carry your work too.

### 0:54–1:24 — FRIENDS MAKE IT HARDER
**VISUAL | P:** Gideon adjusts his camera but does not take a photo. Luc starts a prayer, stops when Zino jokes, then simply squeezes his shoulder.

**ZINO (P):** When I come back, this compound go small.

**GIDEON (P):** Your mouth already big enough.

### 1:24–1:50 — HOOK
**VISUAL | P:** At dawn, Zino takes one last bucket from the well. The road beyond the gate fills the final frame.

**END CARD:** *EPISODE 43 — A DAY AWAY*

**Fact boundary:** Do not state who travelled with Zino, how packing was financed, the school name or a literal farewell event.

---

# EPISODE 43 — “A DAY AWAY”

**Runtime:** 2:00  
**Logline:** A day through mountains and valleys turns Zino's confidence into the smallest thing in the frame.  
**Fact tier:** **C** — the boarding school took a day to reach and lay beyond mountains and valleys. **P** — travel method, companions, road incidents, inner narration and dialogue.

### 0:00–0:20 — THE GATE
**VISUAL | P:** Zino walks out of Fiango's compound gate with bags. The well and mango tree recede behind him. Do not identify a vehicle.

### 0:20–0:58 — LANDSCAPE CHANGES
**VISUAL | C journey / P staging:** Familiar town gives way to rising road, valleys and long mountain views. The day shifts through morning, afternoon and late light.

**ZINO (V.O., P):** From Fiango, every road look like e know somebody. This one keep going.

### 0:58–1:30 — THE HERO CANNOT SHORTEN IT
**FANTASY | P:** Grand-Chukuchuku, in navy and gold, takes one confident step across a valley. The step stops at the edge. He looks back at Zino rather than carrying him.

### 1:30–2:00 — HOOK
**VISUAL | C destination / P staging:** A distant gate and school buildings come into view as the last light leaves. Zino tightens his hand around his bag.

**END CARD:** *EPISODE 44 — THE GATE*

**Fact boundary:** The geography and day-long distance are confirmed; exact road, vehicle, weather, luggage and travel party are not.

---

# EPISODE 44 — “THE GATE”

**Runtime:** 1:55  
**Logline:** Zino reaches the school he chose and sees, in one glance, how much money and certainty other students carry.  
**Fact tier:** **C** — the remote school had top students, rich parents, white teachers and priests. **P** — gate, luggage, arrival order, individual people, dialogue and Zino's observations.

### 0:00–0:22 — FIRST IMPRESSION
**VISUAL | C environment / P observation:** Polished luggage, neat uniforms and confident family movements pass in fragments. This is Zino's impression, not a claim about every family at the school.

### 0:22–0:52 — A DIFFERENT AUTHORITY
**VISUAL | C environment / P staging:** A white teacher crosses the grounds; a priest passes students at a distance. A bell cuts conversation into organised lines.

### 0:52–1:25 — ZINO MAKES HIMSELF SMALLER
**VISUAL | P:** Zino sees mud on his own bag, wipes it, then stops because it will not come clean. He pulls his shoulders back instead.

**ZINO (P, under breath):** I fit stand here.

### 1:25–1:55 — HOOK
**VISUAL | P:** A dormitory door closes behind him. On the wall: empty hooks, tightly made beds, and rules he cannot read before the bell sounds again.

**END CARD:** *EPISODE 45 — FIRST BELL*

**Fact boundary:** No individual parent, teacher, priest, school rule, uniform or staff behaviour is established as a real person or event.

---

# EPISODE 45 — “FIRST BELL”

**Runtime:** 1:50  
**Logline:** Zino wants to prove he can learn a new routine in one morning; every bell tells him someone else already knows the rules.  
**Fact tier:** **C** — boarding school brought a huge change in environment, routine and discipline. **P** — exact waking time, sequence, dormitory arrangement, dialogue and individual gestures.

### 0:00–0:18 — BEFORE LIGHT
**SOUND | P:** A bell tears through sleep. Beds creak. Shoes hit a hard floor. Keep the hour unknown.

### 0:18–0:52 — TOO SLOW, THEN TOO FAST
**VISUAL | P:** Zino follows the movement of boys making beds, washing and forming a line. He is last at one task, then overcorrects at the next. No officer or punishment is invented.

### 0:52–1:22 — A RULE HE CAN USE
**VISUAL | P:** Zino notices a simple visual cue—where to put his shoes, how to fold a blanket, how a line turns—and copies it accurately. His intelligence helps when he watches instead of performs.

**ZINO (V.O., P):** For here, person no clap when you sharp. Person just expect am.

### 1:22–1:50 — HOOK
**VISUAL | P:** The line turns toward class. Zino sees the perimeter fence beyond the grounds for the first time.

**END CARD:** *EPISODE 46 — THE TABLE*

**Fact boundary:** Routine and discipline are confirmed; all timings, chores, lines and narration are proposed composites.

---

# EPISODE 46 — “THE TABLE”

**Runtime:** 1:55  
**Logline:** At a shared boarding-school meal, Zino learns that hunger is not always loud and belonging can be measured by who knows where to sit.  
**Fact tier:** **C** — boarding school brought strict discipline; students later jumped the fence to buy food. **R** — specific food, meal routine and timing. **P** — dining hall, seats, dialogue and moment-to-moment hunger.

### 0:00–0:22 — THE SEAT
**VISUAL | P:** Students fill a long table with practised speed. Zino pauses at an open place, uncertain whether it is his, then sits when no one stops him.

### 0:22–0:56 — WHAT IS NOT SAID
**VISUAL | P:** Conversation moves around food, home and whose parents visited. Zino listens more than he speaks. He does not invent hardship for the other students or claim the meal is inadequate.

### 0:56–1:27 — A SMALL SKILL
**VISUAL | P:** A student struggles with a school question scratched on a margin. Zino quietly explains it with a football metaphor. The student understands; Zino has made one useful connection.

### 1:27–1:55 — HOOK
**VISUAL | R boundary / P staging:** As the meal ends, two students glance toward the fence. Their whispered plan is inaudible. Zino notices, but does not follow.

**END CARD:** *EPISODE 47 — WHO BELONGS*

**Fact boundary:** Do not identify food, dining rules, visiting parents, fence-crossers, or a reason for hunger before Zino supplies the memory.

---

# EPISODE 47 — “WHO BELONGS”

**Runtime:** 1:55  
**Logline:** Zino wants to answer every small test with wit; the boarding school's unspoken rankings teach him when holding back is a decision.  
**Fact tier:** **C** — the school had bullying, top students and wealthier families. **R** — actual bullying forms, people and incidents. **P** — social moment, dialogue, classroom/dorm setting and outcome.

### 0:00–0:20 — THE LOOK
**VISUAL | P:** An older student looks over Zino's worn bag and moves on. No insult is spoken, so no unremembered wording becomes fact.

### 0:20–0:54 — THE ANSWER HE DOES NOT GIVE
**VISUAL | P:** Zino begins a sharp reply. His eye catches a group of newer boys watching. He swallows the line and steps aside, angry with himself for it.

### 0:54–1:25 — A DIFFERENT KIND OF WIN
**VISUAL | P:** In class, a difficult question lands. Zino writes the answer methodically. A teacher takes the work without praise or scorn; the moment belongs to Zino.

### 1:25–1:55 — HOOK
**VISUAL | P:** At night, he opens a letter or blank page intended for home but does not write an invented message. He hears laughter somewhere beyond the dormitory wall.

**END CARD:** *EPISODE 48 — THE FIRST TERM*

**Fact boundary:** Bullying is confirmed as part of the environment, but this episode does not claim a particular bully, insult, assault, teacher response or victimisation event.

---

# EPISODE 48 — “THE FIRST TERM”

**Runtime:** 2:00  
**Logline:** Zino wants the first term to prove he belongs; the person who left Fiango begins learning how to survive distance without forgetting home.  
**Fact tier:** **C** — Zino spent two years at the remote boarding high school after five Fiango day-school years. **P** — term boundary, study scene, home communication, dialogue and final images.

### 0:00–0:22 — THE PATTERN
**VISUAL | P:** A compressed but specific routine: bell, made bed, classroom board, shoes in line, study lamp. Zino now reaches each place before the next bell.

### 0:22–0:58 — HOME IN OBJECTS
**VISUAL | P on C world:** He touches a football mark in his exercise book, then draws the Fiango well beside a maths problem. It is a private habit, not an asserted historical drawing.

### 0:58–1:30 — GRAND-CHUKUCHUKU CHANGES
**FANTASY | P:** Zino tells no story. Grand-Chukuchuku appears only as a quiet adult figure across the dormitory window, navy suit visible against the mountains. He does not enter the room.

### 1:30–2:00 — HOOK
**VISUAL | C school fact / P staging:** Beyond Zino's desk, the fence catches rain. A distant light travels on the other side. Zino looks up, then returns to his work.

**END CARD:** *EPISODE 49 — THE FENCE*

**Fact boundary:** This episode establishes adaptation during first boarding year. It does not state a term calendar, contact method with home, individual fence event or A-Level outcome.

